# FOOTBALL CAREER: DYNASTY

Progetto Godot 4.4.1 per Android, gameplay 2D portrait.

## Cosa contiene questa prima base
- Creazione carriera con scelta Paese e divisione:
  - Inghilterra: League Two, League One, Championship, Premier League
  - Spagna: Liga 2, Liga 1
  - Francia: Ligue 3, Ligue 2, Ligue 1
  - Italia: Serie C, Serie B, Serie A
  - Germania: Bundesliga 2, Bundesliga 1
- Nome club personalizzabile.
- Rosa iniziale generata casualmente.
- Giocatori con ruolo, età, valutazione, potenziale, morale, condizione, stipendio e contratto.
- Prima simulazione di campionato e calendario.
- Mercato con negoziazione di cartellino, stipendio, durata e ruolo (Cruciale, Importante, Promessa, Turnover, Sporadico).
- Coppe nazionali e competizioni UEFA elencate nel menu.
- Salvataggio locale della carriera.
- Workflow GitHub Actions per esportare l'APK Android.

## Importante: stato del progetto
Questa è una **base iniziale giocabile**, non ancora il manager completo promesso dal concept. Il motore delle stagioni complete, i campionati paralleli, promozioni/retrocessioni, coppe con sorteggi e tabelloni, database licenziato dei calciatori reali, scouting avanzato, trattative con controfferte e rifinitura UI sono i prossimi moduli da sviluppare e testare. Le coppe sono al momento presenti come struttura/menu, non ancora simulabili.

## Aprire il progetto
1. Installa Godot 4.4.1.
2. Estrai la cartella e apri `project.godot`.
3. Premi F6/F6 oppure F5 per eseguire la scena principale.

## Creare il repository GitHub
1. Su GitHub premi **New repository**.
2. Nome consigliato: `football-career-dynasty`.
3. Imposta il repository come Public o Private a tua scelta.
4. Carica tutto il contenuto di questa cartella nella root del repository (non caricare la cartella contenitore come sottocartella).
5. Apri **Actions** e avvia `Build Android APK` con **Run workflow**, oppure fai un push sul branch `main`.

## Scaricare l'APK
Quando il workflow termina:
1. Apri la run completata in GitHub Actions.
2. Scorri fino ad **Artifacts**.
3. Scarica `FOOTBALL-CAREER-DYNASTY-Android`.
4. Estrai lo ZIP e installa l'APK sul dispositivo Android.

## Prossimi moduli
1. Database competizioni e regole per ogni nazione.
2. Simulazione calendario completo e classifica di tutte le squadre.
3. Coppe nazionali, Champions League, Europa League e Conference League con sorteggi e tabelloni.
4. Mercato a più round: club, agente e calciatore con richieste e controfferte.
5. Ruoli contrattuali con aspettative di minutaggio e morale dinamico.
6. Giocatori reali da fonte dati con licenza compatibile + giocatori generati e creati dall'utente.
7. Vivaio, staff, tattiche, infortuni, finanze, sponsor e salvataggi multipli.
