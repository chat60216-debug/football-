extends RefCounted
class_name DynastyGameState

const COUNTRIES := {
    "Inghilterra": ["League Two", "League One", "Championship", "Premier League"],
    "Spagna": ["Liga 2", "Liga 1"],
    "Francia": ["Ligue 3", "Ligue 2", "Ligue 1"],
    "Italia": ["Serie C", "Serie B", "Serie A"],
    "Germania": ["Bundesliga 2", "Bundesliga 1"]
}
const ROLES := ["Cruciale", "Importante", "Promessa", "Turnover", "Sporadico"]

var club_name := "Nova FC"
var country := "Italia"
var division := "Serie C"
var season := 2026
var matchday := 1
var points := 0
var wins := 0
var draws := 0
var losses := 0
var budget := 1500000
var wage_budget := 900000
var players: Array[Dictionary] = []
var market: Array[Dictionary] = []
var fixtures: Array[Dictionary] = []
var cup_log: Array[String] = []
var last_match := "La tua carriera deve ancora iniziare."
var started := false

func start_career(name: String, selected_country: String, selected_division: String) -> void:
    club_name = name.strip_edges()
    if club_name.is_empty():
        club_name = "Nova FC"
    country = selected_country
    division = selected_division
    season = 2026
    matchday = 1
    points = 0
    wins = 0
    draws = 0
    losses = 0
    budget = starting_budget(selected_division)
    wage_budget = starting_wages(selected_division)
    players.clear()
    market.clear()
    fixtures.clear()
    cup_log.clear()
    generate_squad()
    generate_market()
    generate_fixtures()
    started = true

func starting_budget(div: String) -> int:
    match div:
        "Premier League", "Liga 1", "Serie A", "Ligue 1", "Bundesliga 1":
            return 12000000
        "Championship", "Liga 2", "Serie B", "Ligue 2", "Bundesliga 2":
            return 3500000
        _:
            return 1200000

func starting_wages(div: String) -> int:
    return int(starting_budget(div) * 0.42)

func generate_squad() -> void:
    var first_names := ["Luca", "Marco", "Andrea", "Matteo", "Samuele", "Davide", "Edoardo", "Riccardo", "Tommaso", "Nicolò", "Gabriel", "Alessio", "Fabio", "Michele", "Cristian", "Youssef", "Daniel", "Leonardo"]
    var last_names := ["Rossi", "Bianchi", "Conti", "Marchetti", "Romano", "Costa", "Ferrari", "Moretti", "Gallo", "Riva", "Greco", "Fontana", "Esposito", "Ricci", "Marino", "Lombardi", "Bruno", "De Luca"]
    var positions := ["POR", "POR", "DIF", "DIF", "DIF", "DIF", "DIF", "DIF", "CEN", "CEN", "CEN", "CEN", "CEN", "CEN", "ATT", "ATT", "ATT", "ATT"]
    for i in range(18):
        var rating := randi_range(48, 68)
        var age := randi_range(18, 34)
        players.append({
            "id": i + 1,
            "name": first_names.pick_random() + " " + last_names.pick_random(),
            "position": positions[i],
            "age": age,
            "rating": rating,
            "potential": clampi(rating + randi_range(3, 22), rating, 88),
            "wage": randi_range(900, 4200) * 12,
            "value": rating * rating * 380,
            "morale": randi_range(60, 85),
            "fitness": randi_range(82, 100),
            "contract_years": randi_range(1, 4),
            "squad_role": ROLES.pick_random()
        })

func generate_market() -> void:
    var first_names := ["Adam", "Victor", "Noah", "Milan", "Luis", "Enzo", "Arthur", "Oscar", "Leo", "Dario", "Hugo", "Rayan"]
    var last_names := ["Silva", "Martin", "Kovac", "Costa", "Diallo", "Muller", "Santos", "Berg", "Lopez", "Moreau", "Novak", "Walker"]
    var positions := ["POR", "DIF", "CEN", "ATT"]
    for i in range(12):
        var rating := randi_range(54, 79)
        market.append({
            "id": 1000 + i,
            "name": first_names.pick_random() + " " + last_names.pick_random(),
            "position": positions.pick_random(),
            "age": randi_range(18, 31),
            "rating": rating,
            "potential": clampi(rating + randi_range(2, 18), rating, 91),
            "value": rating * rating * 500,
            "wage": randi_range(1800, 9500) * 12,
            "demand_role": ROLES.pick_random(),
            "club": ["FC Northbridge", "Real Montelago", "Olympique Valmont", "SV Adler", "Atletico Marina"].pick_random()
        })

func generate_fixtures() -> void:
    var opponents := ["United Athletic", "Real Montelago", "Olympique Valmont", "SV Adler", "Atletico Marina", "Northbridge FC", "Sporting Rivoli", "Dynamo West"]
    opponents.shuffle()
    for i in range(8):
        fixtures.append({"round": i + 1, "opponent": opponents[i], "home": i % 2 == 0, "played": false, "result": ""})

func play_next_match() -> Dictionary:
    if matchday > fixtures.size():
        season += 1
        matchday = 1
        generate_fixtures()
    var fixture: Dictionary = fixtures[matchday - 1]
    var avg := 0.0
    for p in players:
        avg += float(p.rating) * (float(p.fitness) / 100.0)
    avg /= maxf(1.0, float(players.size()))
    var strength := int(avg + randi_range(-13, 13))
    var opponent_strength := randi_range(48, 75)
    var gf := maxi(0, int(round((strength - opponent_strength + 8) / 13.0)) + randi_range(0, 2))
    var ga := maxi(0, int(round((opponent_strength - strength + 8) / 14.0)) + randi_range(0, 2))
    if gf > ga:
        wins += 1
        points += 3
    elif gf == ga:
        draws += 1
        points += 1
    else:
        losses += 1
    fixture.played = true
    fixture.result = "%d-%d" % [gf, ga]
    fixtures[matchday - 1] = fixture
    for p in players:
        p.fitness = maxi(35, p.fitness - randi_range(5, 12))
        p.morale = clampi(p.morale + (3 if gf > ga else (-2 if gf < ga else 1)), 35, 99)
    var venue := "Casa" if fixture.home else "Trasferta"
    last_match = "%s %s %d-%d %s" % [venue, club_name if fixture.home else fixture.opponent, gf if fixture.home else ga, ga if fixture.home else gf, fixture.opponent if fixture.home else club_name]
    matchday += 1
    return {"gf": gf, "ga": ga, "opponent": fixture.opponent, "home": fixture.home, "strength": strength, "opponent_strength": opponent_strength}

func save_game() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("career", "club_name", club_name)
    cfg.set_value("career", "country", country)
    cfg.set_value("career", "division", division)
    cfg.set_value("career", "season", season)
    cfg.set_value("career", "matchday", matchday)
    cfg.set_value("career", "points", points)
    cfg.set_value("career", "wins", wins)
    cfg.set_value("career", "draws", draws)
    cfg.set_value("career", "losses", losses)
    cfg.set_value("career", "budget", budget)
    cfg.set_value("career", "wage_budget", wage_budget)
    cfg.set_value("career", "players", players)
    cfg.set_value("career", "market", market)
    cfg.set_value("career", "fixtures", fixtures)
    cfg.set_value("career", "cup_log", cup_log)
    cfg.set_value("career", "last_match", last_match)
    cfg.save("user://career.cfg")

func load_game() -> bool:
    var cfg := ConfigFile.new()
    if cfg.load("user://career.cfg") != OK:
        return false
    for key in ["club_name", "country", "division", "season", "matchday", "points", "wins", "draws", "losses", "budget", "wage_budget", "players", "market", "fixtures", "cup_log", "last_match"]:
        if cfg.has_section_key("career", key):
            set(key, cfg.get_value("career", key))
    started = true
    return true
