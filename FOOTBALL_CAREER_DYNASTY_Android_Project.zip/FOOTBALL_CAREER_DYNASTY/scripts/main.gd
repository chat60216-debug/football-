extends Control

const StateScript = preload("res://scripts/game_state.gd")
var state = StateScript.new()
var page := "home"
var selected_player: Dictionary = {}
var selected_offer_player: Dictionary = {}
var offer_fee := 0
var offer_wage := 0
var offer_years := 3
var offer_role := "Importante"
var status_label: Label

const BG := Color("#0b1220")
const PANEL := Color("#151f32")
const ACCENT := Color("#43d39e")
const TEXT := Color("#edf3ff")
const MUTED := Color("#9baac2")

func _ready() -> void:
    randomize()
    if state.load_game():
        page = "dashboard"
    show_page()

func clear_screen() -> void:
    for child in get_children():
        child.queue_free()

func make_label(value: String, size: int = 20, color: Color = TEXT) -> Label:
    var label := Label.new()
    label.text = value
    label.add_theme_font_size_override("font_size", size)
    label.add_theme_color_override("font_color", color)
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    return label

func make_button(value: String, callback: Callable) -> Button:
    var b := Button.new()
    b.text = value
    b.custom_minimum_size = Vector2(0, 54)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.add_theme_font_size_override("font_size", 18)
    b.add_theme_color_override("font_color", TEXT)
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", panel_style(ACCENT.darkened(0.72)))
    b.add_theme_stylebox_override("hover", panel_style(ACCENT.darkened(0.48)))
    b.pressed.connect(callback)
    return b

func panel_style(color: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = color
    s.corner_radius_top_left = 12
    s.corner_radius_top_right = 12
    s.corner_radius_bottom_left = 12
    s.corner_radius_bottom_right = 12
    s.content_margin_left = 12
    s.content_margin_right = 12
    s.content_margin_top = 8
    s.content_margin_bottom = 8
    return s

func build_base(title_text: String) -> VBoxContainer:
    clear_screen()
    var bg := ColorRect.new()
    bg.color = BG
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)
    var scroll := ScrollContainer.new()
    scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scroll.offset_left = 18
    scroll.offset_right = -18
    scroll.offset_top = 18
    scroll.offset_bottom = -18
    add_child(scroll)
    var root := VBoxContainer.new()
    root.add_theme_constant_override("separation", 14)
    root.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(root)
    root.add_child(make_label("FOOTBALL CAREER: DYNASTY", 15, ACCENT))
    root.add_child(make_label(title_text, 30))
    return root

func show_page() -> void:
    match page:
        "home": show_home()
        "create": show_create()
        "dashboard": show_dashboard()
        "squad": show_squad()
        "market": show_market()
        "cups": show_cups()
        "calendar": show_calendar()
        "negotiation": show_negotiation()

func show_home() -> void:
    var root := build_base("La tua dinastia calcistica")
    root.add_child(make_label("Costruisci una società, scala le divisioni e conquista l'Europa.", 19, MUTED))
    root.add_child(make_label("CAMPIONATI • CALCIOMERCATO • COPPE • CARRIERA", 14, ACCENT))
    root.add_child(make_button("NUOVA CARRIERA", func(): page = "create"; show_page()))
    if state.started:
        root.add_child(make_button("CONTINUA CARRIERA", func(): page = "dashboard"; show_page()))
    root.add_child(make_label("Versione iniziale giocabile • Salvataggio locale", 14, MUTED))

func show_create() -> void:
    var root := build_base("Crea la tua società")
    root.add_child(make_label("Nome del club"))
    var club_input := LineEdit.new()
    club_input.placeholder_text = "Es. AC Nova Milano"
    club_input.text = "Nova FC"
    club_input.custom_minimum_size.y = 52
    root.add_child(club_input)
    root.add_child(make_label("Paese"))
    var country_select := OptionButton.new()
    for country in StateScript.COUNTRIES.keys():
        country_select.add_item(country)
    root.add_child(country_select)
    root.add_child(make_label("Divisione di partenza"))
    var division_select := OptionButton.new()
    root.add_child(division_select)
    var update_divisions := func(_index: int = 0):
        division_select.clear()
        var selected_country: String = country_select.get_item_text(country_select.selected)
        for div in StateScript.COUNTRIES[selected_country]:
            division_select.add_item(div)
    country_select.item_selected.connect(update_divisions)
    update_divisions.call()
    root.add_child(make_label("La rosa iniziale sarà generata casualmente.", 15, MUTED))
    root.add_child(make_button("CREA CARRIERA", func():
        var c: String = country_select.get_item_text(country_select.selected)
        var d: String = division_select.get_item_text(division_select.selected)
        state.start_career(club_input.text, c, d)
        state.save_game()
        page = "dashboard"
        show_page()
    ))
    root.add_child(make_button("INDIETRO", func(): page = "home"; show_page()))

func show_dashboard() -> void:
    var root := build_base(state.club_name)
    root.add_child(make_label("%s  •  %s  •  Stagione %d" % [state.country, state.division, state.season], 16, MUTED))
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", panel_style(PANEL))
    var stats := VBoxContainer.new()
    panel.add_child(stats)
    stats.add_child(make_label("CLASSIFICA / STAGIONE", 15, ACCENT))
    stats.add_child(make_label("%d punti  |  %dV %dN %dP" % [state.points, state.wins, state.draws, state.losses], 22))
    stats.add_child(make_label("Budget: €%s  •  Monte ingaggi: €%s" % [fmt_money(state.budget), fmt_money(state.wage_budget)], 15, MUTED))
    root.add_child(panel)
    root.add_child(make_label("ULTIMA PARTITA", 14, ACCENT))
    root.add_child(make_label(state.last_match, 17))
    root.add_child(make_button("GIOCA PROSSIMA PARTITA", func():
        var result: Dictionary = state.play_next_match()
        state.save_game()
        show_match_result(result)
    ))
    root.add_child(make_button("Rosa e tattiche", func(): page = "squad"; show_page()))
    root.add_child(make_button("Calciomercato e trattative", func(): page = "market"; show_page()))
    root.add_child(make_button("Coppe nazionali ed europee", func(): page = "cups"; show_page()))
    root.add_child(make_button("Calendario e risultati", func(): page = "calendar"; show_page()))
    root.add_child(make_button("Salva carriera", func(): state.save_game(); show_notice("Carriera salvata sul dispositivo.")))
    root.add_child(make_button("Menu principale", func(): page = "home"; show_page()))

func show_match_result(result: Dictionary) -> void:
    var root := build_base("Fischio finale")
    var home_name: String = state.club_name if result.home else result.opponent
    var away_name: String = result.opponent if result.home else state.club_name
    var home_goals: int = result.gf if result.home else result.ga
    var away_goals: int = result.ga if result.home else result.gf
    root.add_child(make_label("%s  %d - %d  %s" % [home_name, home_goals, away_goals, away_name], 24))
    root.add_child(make_label("Forza squadra: %d  •  Avversario: %d" % [result.strength, result.opponent_strength], 15, MUTED))
    root.add_child(make_label("La condizione e il morale della rosa sono stati aggiornati.", 16))
    root.add_child(make_button("TORNA ALLA SOCIETÀ", func(): page = "dashboard"; show_page()))

func show_squad() -> void:
    var root := build_base("Rosa e giocatori")
    root.add_child(make_label("%d calciatori • rosa generata casualmente" % state.players.size(), 15, MUTED))
    for p in state.players:
        var line := "%s  |  %s  |  VAL %d  POT %d\nEtà %d • Morale %d • Condizione %d • Ruolo %s" % [p.name, p.position, p.rating, p.potential, p.age, p.morale, p.fitness, p.squad_role]
        var b := make_button(line, func(): selected_player = p; show_player_detail())
        b.custom_minimum_size.y = 88
        root.add_child(b)
    root.add_child(make_button("INDIETRO", func(): page = "dashboard"; show_page()))

func show_player_detail() -> void:
    var root := build_base(selected_player.name)
    root.add_child(make_label("%s • %d anni" % [selected_player.position, selected_player.age], 17, MUTED))
    root.add_child(make_label("Valutazione %d  |  Potenziale %d" % [selected_player.rating, selected_player.potential], 22))
    root.add_child(make_label("Stipendio annuo: €%s" % fmt_money(selected_player.wage)))
    root.add_child(make_label("Ruolo: %s • Contratto: %d anni" % [selected_player.squad_role, selected_player.contract_years]))
    root.add_child(make_button("Cambia ruolo in rosa", func():
        var opts := AcceptDialog.new()
        opts.title = "Assegna ruolo"
        var select := OptionButton.new()
        for role in StateScript.ROLES:
            select.add_item(role)
        opts.add_child(select)
        opts.confirmed.connect(func():
            selected_player.squad_role = select.get_item_text(select.selected)
            state.save_game()
            show_player_detail()
        )
        add_child(opts)
        opts.popup_centered()
    ))
    root.add_child(make_button("INDIETRO", func(): page = "squad"; show_page()))

func show_market() -> void:
    var root := build_base("Calciomercato")
    root.add_child(make_label("Osserva, scegli un obiettivo e apri una trattativa.", 16, MUTED))
    root.add_child(make_label("Budget trasferimenti: €%s" % fmt_money(state.budget), 18, ACCENT))
    for p in state.market:
        var b := make_button("%s • %s • VAL %d • %d anni\nValore €%s • Richiesta ingaggio €%s/anno" % [p.name, p.position, p.rating, p.age, fmt_money(p.value), fmt_money(p.wage)], func():
            selected_offer_player = p
            offer_fee = p.value
            offer_wage = p.wage
            offer_years = 3
            offer_role = "Importante"
            page = "negotiation"
            show_page()
        )
        b.custom_minimum_size.y = 88
        root.add_child(b)
    root.add_child(make_button("INDIETRO", func(): page = "dashboard"; show_page()))

func show_negotiation() -> void:
    var root := build_base("Trattativa: " + selected_offer_player.name)
    root.add_child(make_label("Club attuale: %s" % selected_offer_player.club, 15, MUTED))
    root.add_child(make_label("Valore stimato: €%s" % fmt_money(selected_offer_player.value)))
    root.add_child(make_label("La tua offerta al club (€)"))
    var fee := SpinBox.new()
    fee.min_value = 0
    fee.max_value = 50000000
    fee.step = 25000
    fee.value = offer_fee
    fee.custom_minimum_size.y = 48
    root.add_child(fee)
    root.add_child(make_label("Stipendio annuo proposto (€)"))
    var wage := SpinBox.new()
    wage.min_value = 0
    wage.max_value = 5000000
    wage.step = 1000
    wage.value = offer_wage
    wage.custom_minimum_size.y = 48
    root.add_child(wage)
    root.add_child(make_label("Durata contratto"))
    var years := OptionButton.new()
    for y in range(1, 6):
        years.add_item("%d anni" % y)
    years.select(2)
    root.add_child(years)
    root.add_child(make_label("Ruolo promesso"))
    var role := OptionButton.new()
    for r in StateScript.ROLES:
        role.add_item(r)
    role.select(StateScript.ROLES.find(offer_role))
    root.add_child(role)
    root.add_child(make_label("Puoi modificare ogni condizione prima di inviare l'offerta.", 14, MUTED))
    root.add_child(make_button("INVIA OFFERTA", func():
        offer_fee = int(fee.value)
        offer_wage = int(wage.value)
        offer_years = years.selected + 1
        offer_role = role.get_item_text(role.selected)
        resolve_negotiation()
    ))
    root.add_child(make_button("ANNULLA", func(): page = "market"; show_page()))

func resolve_negotiation() -> void:
    var ask_fee: int = selected_offer_player.value
    var ask_wage: int = selected_offer_player.wage
    var fee_ok := offer_fee >= int(ask_fee * randf_range(0.82, 1.12))
    var wage_ok := offer_wage >= int(ask_wage * randf_range(0.88, 1.15))
    var role_ok := offer_role == "Cruciale" or offer_role == "Importante" or offer_role == selected_offer_player.demand_role
    var result_text := ""
    if fee_ok and wage_ok and role_ok and offer_fee <= state.budget:
        state.budget -= offer_fee
        state.wage_budget -= offer_wage
        var new_player: Dictionary = selected_offer_player.duplicate(true)
        new_player.wage = offer_wage
        new_player.contract_years = offer_years
        new_player.squad_role = offer_role
        new_player.morale = 82
        state.players.append(new_player)
        state.market.erase(selected_offer_player)
        result_text = "ACCORDO RAGGIUNTO! %s ha accettato. Ingaggio: €%s/anno, contratto %d anni, ruolo %s." % [new_player.name, fmt_money(offer_wage), offer_years, offer_role]
    elif offer_fee > state.budget:
        result_text = "Trattativa fallita: l'offerta supera il budget disponibile."
    elif not fee_ok:
        result_text = "Il club ha rifiutato. Chiede una cifra più alta. Puoi tornare a trattare."
    elif not wage_ok:
        result_text = "Il giocatore non è soddisfatto dello stipendio. Prova ad alzare la parte fissa o rivedere il ruolo."
    else:
        result_text = "Il giocatore non crede al ruolo proposto. Chiede garanzie di minutaggio o un ruolo più importante."
    state.save_game()
    show_notice(result_text)

func show_cups() -> void:
    var root := build_base("Coppe e competizioni")
    root.add_child(make_label("Coppe nazionali", 20, ACCENT))
    var national := {
        "Italia": ["Coppa Italia"],
        "Inghilterra": ["FA Cup", "Carabao Cup"],
        "Spagna": ["Copa del Rey"],
        "Francia": ["Coupe de France"],
        "Germania": ["DFB-Pokal"]
    }
    for cup in national.get(state.country, []):
        root.add_child(make_label("🏆 " + cup, 18))
    root.add_child(make_label("Competizioni UEFA", 20, ACCENT))
    for cup in ["UEFA Champions League", "UEFA Europa League", "UEFA Conference League"]:
        root.add_child(make_label("🌍 " + cup, 18))
    root.add_child(make_label("Le qualificazioni europee dipenderanno dal piazzamento in campionato e dai risultati delle coppe. Il motore completo dei sorteggi e dei tabelloni è previsto nel modulo competizioni.", 15, MUTED))
    root.add_child(make_button("INDIETRO", func(): page = "dashboard"; show_page()))

func show_calendar() -> void:
    var root := build_base("Calendario")
    for f in state.fixtures:
        var venue := "Casa" if f.home else "Trasferta"
        var outcome := " • " + f.result if f.played else ""
        root.add_child(make_label("Giornata %d  •  %s vs %s%s" % [f.round, state.club_name if f.home else f.opponent, f.opponent if f.home else state.club_name, outcome], 16))
    root.add_child(make_button("INDIETRO", func(): page = "dashboard"; show_page()))

func show_notice(message: String) -> void:
    var dialog := AcceptDialog.new()
    dialog.dialog_text = message
    dialog.title = "FOOTBALL CAREER: DYNASTY"
    dialog.confirmed.connect(func(): show_page())
    add_child(dialog)
    dialog.popup_centered(Vector2i(560, 300))

func fmt_money(value: int) -> String:
    var raw := str(value)
    var out := ""
    var count := 0
    for i in range(raw.length() - 1, -1, -1):
        out = raw[i] + out
        count += 1
        if count % 3 == 0 and i > 0:
            out = "." + out
    return out

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        state.save_game()
        get_tree().quit()
